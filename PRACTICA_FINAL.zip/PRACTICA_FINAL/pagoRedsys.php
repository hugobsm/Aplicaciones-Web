<?php
header("Location: formularioPago.php");
exit;
?>
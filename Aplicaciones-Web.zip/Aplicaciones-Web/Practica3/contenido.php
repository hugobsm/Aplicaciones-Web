<?php

require_once("includes/config.php");

$tituloPagina = 'Contenido';

	$contenidoPrincipal='';
    if (!isset($_SESSION["login"]))
    {
        $contenidoPrincipal=<<<EOS
            <h1>Error</h1>
            <p>Contenido para usuarios registrados.</p>
        EOS;
    } 
    else 
    {
        $contenidoPrincipal=<<<EOS
	<h1>Automóviles olvidados</h1>
	<p>El Citroën SM fue un coche adelantado a su época, en los años 70. Fue presentado en 1970, fruto del acuerdo entre Citroën y Maserati. Este automóvil incorporaba suspensión hidroneumática automática, faros direccionables, dirección asistida variable en función de la velocidad, caja de cambios de 5 velocidades, elevalunas eléctricos y frenos de disco en las cuatro ruedas.</p>

	<p>El Citroën SM era capaz de alcanzar 220Km/h y montaba un motor Masetati 2.7 V6 de 172 CV. Este motor fue diseñado a partir de un V8 ... </p>

	<p>El Citroën SM se dejó de fabricar en 1975 debido a ...</p>
EOS;
    } 

require("includes/comun/plantilla.php");
?>

